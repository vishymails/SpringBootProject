TO run given project 

Install Docker latest with Docker compose 

then go to Project folder 

then run : 

docker-compose -f mysql up

There are two containers will come up.

mysql + adminer app

then open http://localhost:8080

User : root
Password : example

Create DB named : fijitsu

Then deploy zip file as Maven Boot Project 


Run the application 
